import { useState, useEffect, useRef } from 'react';
import axios from 'axios';

const initials = (value = '?') => value.trim().charAt(0).toUpperCase() || '?';

export default function ChatWindow({ chat, messages, currentUser, typingUsers, onSend, socket, token, API, onBack, onlineMap }) {
  const [text, setText] = useState('');
  const [uploading, setUploading] = useState(false);
  const messagesEndRef = useRef(null);
  const typingTimeout = useRef(null);
  const fileInputRef = useRef(null);

  useEffect(() => { messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' }); }, [messages]);
  useEffect(() => () => clearTimeout(typingTimeout.current), []);

  const handleTyping = (value) => {
    setText(value);
    if (!socket || !chat) return;
    socket.emit('typing:start', { chatId: chat.id });
    clearTimeout(typingTimeout.current);
    typingTimeout.current = setTimeout(() => socket.emit('typing:stop', { chatId: chat.id }), 1300);
  };
  const handleSend = () => {
    if (!text.trim() || !chat) return;
    onSend(text.trim()); setText('');
    if (socket) socket.emit('typing:stop', { chatId: chat.id });
  };
  const handleKeyDown = (e) => { if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); handleSend(); } };
  const handleFile = async (e) => {
    const file = e.target.files?.[0]; if (!file || !chat) return;
    setUploading(true);
    try {
      const form = new FormData(); form.append('file', file);
      const res = await axios.post(`${API}/upload`, form, { headers: { Authorization: `Bearer ${token}`, 'Content-Type': 'multipart/form-data' } });
      const isImage = file.type.startsWith('image/'); const isVideo = file.type.startsWith('video/');
      onSend('', res.data.url, isImage ? 'image' : isVideo ? 'video' : 'file');
    } catch (err) { console.error(err); alert('Upload failed. Please try again.'); }
    finally { setUploading(false); if (fileInputRef.current) fileInputRef.current.value = ''; }
  };

  if (!chat) return <section className="chat-window"><div className="chat-empty-state"><div className="empty-illustration">✉</div><h2>Your conversations, reimagined.</h2><p>Pick a conversation from your inbox or discover people to start a new chat. Good conversations start with hello.</p></div></section>;

  const typingText = Object.values(typingUsers).filter(Boolean).join(', ');
  const isOnline = chat.type === 'private' && chat.members?.some(id => id !== currentUser?.id && onlineMap?.[id]);

  return <section className="chat-window">
    <header className="chat-header">
      <button className="icon-button mobile-back" onClick={onBack} aria-label="Back to chats">←</button>
      <div className={`avatar ${chat.type === 'group' ? 'avatar-group' : ''}`}>{chat.type === 'group' ? '♧' : initials(chat.name || '?')}</div>
      <div className="chat-header-copy"><h2>{chat.name || 'Conversation'}</h2><p>{chat.type === 'group' ? `${chat.members?.length || 0} members · Group conversation` : (isOnline ? 'Online now' : 'Direct conversation')}</p></div>
      <div className="header-presence"><span style={{ background: chat.type === 'group' ? '#8b7cff' : (isOnline ? '#58d9a8' : '#65718c') }} />{chat.type === 'group' ? 'GROUP' : (isOnline ? 'ONLINE' : 'CHAT')}</div>
    </header>

    <div className="messages-area">
      {messages.length === 0 && <div className="empty-list"><div className="empty-icon">✧</div><strong>Say hello 👋</strong><p>This is the start of your conversation. Send the first message.</p></div>}
      {messages.map(m => {
        const isMe = m.senderId === currentUser?.id;
        return <div key={m.id} className="message-row" style={{ justifyContent: isMe ? 'flex-end' : 'flex-start' }}>
          <div className={`message-bubble ${isMe ? 'outgoing' : 'incoming'}`}>
            {!isMe && chat.type === 'group' && <div className="message-sender">{m.senderName}</div>}
            {m.mediaUrl && m.mediaType === 'image' && <img src={m.mediaUrl} alt="Shared attachment" style={{ maxWidth: 'min(260px, 100%)', borderRadius: 10, marginBottom: 5, display: 'block' }} />}
            {m.mediaUrl && m.mediaType === 'video' && <video src={m.mediaUrl} controls style={{ maxWidth: 'min(280px, 100%)', borderRadius: 10, marginBottom: 5 }} />}
            {m.mediaUrl && m.mediaType === 'file' && <a href={m.mediaUrl} target="_blank" rel="noreferrer">Open attachment</a>}
            {m.text && <div style={{ whiteSpace: 'pre-wrap' }}>{m.text}</div>}
            <div className="message-time">{new Date(m.createdAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</div>
          </div>
        </div>;
      })}
      <div ref={messagesEndRef} />
    </div>
    {typingText && <div className="typing-indicator">{typingText} typing…</div>}
    <div className="message-composer">
      <button className="attach-button" onClick={() => fileInputRef.current?.click()} disabled={uploading} title="Attach image or video" aria-label="Attach file">{uploading ? '…' : '＋'}</button>
      <input type="file" ref={fileInputRef} style={{ display: 'none' }} accept="image/*,video/*" onChange={handleFile} />
      <input className="message-input" placeholder="Write a message…" value={text} onChange={e => handleTyping(e.target.value)} onKeyDown={handleKeyDown} aria-label="Message" />
      <button className="send-button" onClick={handleSend} disabled={!text.trim()} title="Send message" aria-label="Send message">➤</button>
    </div>
  </section>;
}
