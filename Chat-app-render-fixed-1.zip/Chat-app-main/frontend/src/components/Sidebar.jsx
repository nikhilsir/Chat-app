import { useMemo, useState } from 'react';

const initials = (value = '?') => value.trim().charAt(0).toUpperCase() || '?';

export default function Sidebar({
  user, chats, users, onlineMap, activeChat,
  onSelectChat, onStartPrivate, onCreateGroup, onRemoveChat, onLogout
}) {
  const [tab, setTab] = useState('chats');
  const [search, setSearch] = useState('');
  const [groupName, setGroupName] = useState('');
  const [selectedMembers, setSelectedMembers] = useState([]);
  const [notice, setNotice] = useState('');

  const filteredChats = useMemo(() => chats.filter(c =>
    `${c.name || ''} ${c.lastMessage?.text || ''}`.toLowerCase().includes(search.toLowerCase())
  ), [chats, search]);
  const filteredUsers = useMemo(() => users.filter(u =>
    `${u.displayName || ''} ${u.username || ''}`.toLowerCase().includes(search.toLowerCase())
  ), [users, search]);

  const toggleMember = (id) => setSelectedMembers(prev =>
    prev.includes(id) ? prev.filter(x => x !== id) : [...prev, id]
  );

  const handleCreateGroup = async () => {
    if (!groupName.trim() || selectedMembers.length === 0) return;
    try {
      await onCreateGroup(groupName.trim(), selectedMembers);
      setGroupName('');
      setSelectedMembers([]);
      setSearch('');
      setTab('chats');
      setNotice('Group created');
    } catch {
      setNotice('Could not create group. Please try again.');
    }
  };

  const handleRemove = async (event, chat) => {
    event.stopPropagation();
    const label = chat.name || 'this conversation';
    if (!window.confirm(`Remove “${label}” from your chat list? This won't delete the other person's copy.`)) return;
    try {
      await onRemoveChat(chat);
      setNotice('Conversation removed from your list');
    } catch {
      setNotice('Could not remove this conversation. Please try again.');
    }
  };

  return (
    <aside className="sidebar">
      <header className="sidebar-header">
        <div className="brand-lockup">
          <div className="brand-mark">✦</div>
          <div><div className="brand-name">Chatter</div><div className="brand-caption">Your space to connect</div></div>
        </div>
        <button className="icon-button logout-button" onClick={onLogout} title="Log out" aria-label="Log out">↗</button>
      </header>

      <div className="profile-strip">
        <div className="avatar avatar-self">{initials(user?.displayName || user?.username)}</div>
        <div className="profile-copy"><strong>{user?.displayName || user?.username}</strong><span>@{user?.username}</span></div>
        <span className="you-pill">YOU</span>
      </div>

      <div className="sidebar-heading-row">
        <div><p className="eyebrow">MESSAGES</p><h2>Inbox <span className="count-pill">{chats.length}</span></h2></div>
        <button className="new-chat-button" onClick={() => { setTab('users'); setSearch(''); }} aria-label="Find people" title="Find people">＋</button>
      </div>

      <label className="search-field">
        <span aria-hidden="true">⌕</span>
        <input placeholder={tab === 'users' ? 'Search people by name or @username' : 'Search conversations'} value={search} onChange={e => setSearch(e.target.value)} />
        {search && <button type="button" className="clear-search" onClick={() => setSearch('')} aria-label="Clear search">×</button>}
      </label>

      <nav className="sidebar-tabs" aria-label="Chat navigation">
        <button className={tab === 'chats' ? 'sidebar-tab active' : 'sidebar-tab'} onClick={() => setTab('chats')}>Chats <span>{chats.length}</span></button>
        <button className={tab === 'users' ? 'sidebar-tab active' : 'sidebar-tab'} onClick={() => setTab('users')}>People <span>{users.length}</span></button>
        <button className={tab === 'group' ? 'sidebar-tab active' : 'sidebar-tab'} onClick={() => setTab('group')}>＋ Group</button>
      </nav>

      {notice && <button className="inline-notice" onClick={() => setNotice('')} title="Dismiss">{notice} <span>×</span></button>}

      <div className="sidebar-list">
        {tab === 'chats' && (filteredChats.length ? filteredChats.map(c => (
          <div key={c.id} role="button" tabIndex={0} className={`conversation-row ${activeChat?.id === c.id ? 'selected' : ''}`} onClick={() => onSelectChat(c)} onKeyDown={e => { if (e.key === 'Enter') onSelectChat(c); }}>
            <div className={`avatar ${c.type === 'group' ? 'avatar-group' : ''}`}>{c.type === 'group' ? '♧' : initials(c.name)}</div>
            <div className="conversation-copy"><div className="conversation-title-line"><strong>{c.name || 'Conversation'}</strong><span className="conversation-time">{c.lastMessage?.createdAt ? new Date(c.lastMessage.createdAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }) : ''}</span></div><p>{c.lastMessage?.text || (c.lastMessage?.mediaUrl ? '📎 Attachment' : 'Start a conversation')}</p></div>
            <button className="remove-chat-button" title="Remove conversation" aria-label={`Remove ${c.name || 'conversation'}`} onClick={e => handleRemove(e, c)}>×</button>
          </div>
        )) : <div className="empty-list"><div className="empty-icon">◌</div><strong>{search ? 'No matching chats' : 'Your inbox is clear'}</strong><p>{search ? 'Try another name or keyword.' : 'Find a person and say hello.'}</p><button className="text-action" onClick={() => { setTab('users'); setSearch(''); }}>Find people →</button></div>)}

        {tab === 'users' && <>
          <div className="list-intro"><strong>Discover people</strong><span>{filteredUsers.length} {filteredUsers.length === 1 ? 'person' : 'people'}</span></div>
          {filteredUsers.length ? filteredUsers.map(u => <button key={u.id} className="person-row" onClick={() => onStartPrivate(u.id)}>
            <div className="avatar-wrap"><div className="avatar">{initials(u.displayName || u.username)}</div><span className={`presence-dot ${onlineMap[u.id] ? 'online' : ''}`} /></div>
            <div className="person-copy"><strong>{u.displayName || u.username}</strong><span>@{u.username}</span></div><span className={`status-label ${onlineMap[u.id] ? 'status-online' : ''}`}>{onlineMap[u.id] ? 'Online' : 'Offline'}</span><span className="person-arrow">↗</span>
          </button>) : <div className="empty-list"><strong>No people found</strong><p>Try searching with a different name or username.</p></div>}
        </>}

        {tab === 'group' && <div className="group-builder">
          <div className="group-icon">♧</div><h3>Create a group</h3><p>Bring your people together in one conversation.</p>
          <label className="field-label">Group name<input className="form-input" placeholder="e.g. Weekend plans" value={groupName} onChange={e => setGroupName(e.target.value)} maxLength={100} /></label>
          <div className="member-picker-heading"><span>Choose members</span><span>{selectedMembers.length} selected</span></div>
          <div className="member-picker">{filteredUsers.map(u => <label key={u.id} className="member-option"><input type="checkbox" checked={selectedMembers.includes(u.id)} onChange={() => toggleMember(u.id)} /><span className="mini-avatar">{initials(u.displayName || u.username)}</span><span>{u.displayName || u.username}<small>@{u.username}</small></span></label>)}</div>
          <button className="primary-button full-width" onClick={handleCreateGroup} disabled={!groupName.trim() || selectedMembers.length === 0}>Create group <span>→</span></button>
        </div>}
      </div>
      <footer className="sidebar-footer"><span className="footer-status-dot" /> All your conversations in one place <span className="footer-version">CHATTER</span></footer>
    </aside>
  );
}
