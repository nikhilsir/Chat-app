import { useState } from 'react';
import { useAuth } from '../context/AuthContext';
import { useNavigate, Link } from 'react-router-dom';

export default function Signup() {
  const [username, setUsername] = useState('');
  const [displayName, setDisplayName] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);
  const { signup } = useAuth();
  const navigate = useNavigate();

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError('');
    setLoading(true);
    try {
      await signup(username, password, displayName);
      navigate('/');
    } catch (err) {
      setError(err.response?.data?.error || 'Signup failed');
    } finally {
      setLoading(false);
    }
  };

  return (
    <main className="auth-page">
      <section className="auth-card">
        <div className="auth-logo">✦</div>
        <p className="eyebrow">JOIN CHATTER</p>
        <h1>Make it a conversation.</h1>
        <p className="auth-subtitle">Create your account and find your people in a calmer, friendlier inbox.</p>
        <form onSubmit={handleSubmit} className="auth-form">
          {error && <div className="auth-error">{error}</div>}
          <input className="auth-input" placeholder="Display name" value={displayName} onChange={e => setDisplayName(e.target.value)} autoComplete="name" required />
          <input className="auth-input" placeholder="Username" value={username} onChange={e => setUsername(e.target.value)} autoComplete="username" required minLength={3} />
          <input className="auth-input" type="password" placeholder="Password (at least 4 characters)" value={password} onChange={e => setPassword(e.target.value)} autoComplete="new-password" required minLength={4} />
          <button className="auth-submit" type="submit" disabled={loading}>{loading ? 'Creating account…' : 'Create account  →'}</button>
        </form>
        <p className="auth-footer">Already have an account? <Link to="/login">Sign in</Link></p>
      </section>
    </main>
  );
}
