import { useState, useEffect, useCallback } from 'react';
import { useAuth } from '../context/AuthContext';
import { useSocket } from '../context/SocketContext';
import axios from 'axios';
import Sidebar from '../components/Sidebar';
import ChatWindow from '../components/ChatWindow';

export default function Chat() {
  const { user, token, API, logout } = useAuth();
  const socket = useSocket();
  const [chats, setChats] = useState([]);
  const [users, setUsers] = useState([]);
  const [activeChat, setActiveChat] = useState(null);
  const [messages, setMessages] = useState([]);
  const [onlineMap, setOnlineMap] = useState({});
  const [typingUsers, setTypingUsers] = useState({});
  const [mobileChatOpen, setMobileChatOpen] = useState(false);

  const headers = { Authorization: `Bearer ${token}` };
  const refreshChats = useCallback(() => {
    if (!token) return Promise.resolve();
    return axios.get(`${API}/chats`, { headers: { Authorization: `Bearer ${token}` } })
      .then(r => setChats(r.data));
  }, [token, API]);

  useEffect(() => {
    if (!token) return;
    const loadUsers = () => axios.get(`${API}/users`, { headers: { Authorization: `Bearer ${token}` } })
      .then(r => {
        setUsers(r.data);
        setOnlineMap(prev => {
          const map = { ...prev };
          r.data.forEach(u => { map[u.id] = u.online; });
          return map;
        });
      }).catch(console.error);
    axios.get(`${API}/chats`, { headers: { Authorization: `Bearer ${token}` } }).then(r => setChats(r.data)).catch(console.error);
    loadUsers();
    // Keep the people directory fresh so newly registered accounts appear without re-login.
    const refreshPeople = setInterval(loadUsers, 30000);
    return () => clearInterval(refreshPeople);
  }, [token, API]);

  useEffect(() => {
    if (!socket) return;
    const onNewMessage = (msg) => {
      setMessages(prev => {
        if (activeChat?.id !== msg.chatId || prev.some(m => m.id === msg.id)) return prev;
        return [...prev, msg];
      });
      setChats(prev => prev.map(c => c.id === msg.chatId ? { ...c, lastMessage: msg, updatedAt: msg.createdAt } : c)
        .sort((a, b) => new Date(b.updatedAt) - new Date(a.updatedAt)));
    };
    const onOnline = ({ userId, online }) => {
      setOnlineMap(prev => ({ ...prev, [userId]: online }));
      setUsers(prev => prev.map(u => u.id === userId ? { ...u, online } : u));
    };
    const onTypingStart = ({ chatId, userId, username }) => {
      if (chatId === activeChat?.id) setTypingUsers(prev => ({ ...prev, [userId]: username }));
    };
    const onTypingStop = ({ chatId, userId }) => {
      if (chatId === activeChat?.id) setTypingUsers(prev => { const next = { ...prev }; delete next[userId]; return next; });
    };
    const onChatNew = () => { refreshChats().catch(console.error); };
    socket.on('message:new', onNewMessage);
    socket.on('user:online', onOnline);
    socket.on('typing:start', onTypingStart);
    socket.on('typing:stop', onTypingStop);
    socket.on('chat:new', onChatNew);
    return () => {
      socket.off('message:new', onNewMessage);
      socket.off('user:online', onOnline);
      socket.off('typing:start', onTypingStart);
      socket.off('typing:stop', onTypingStop);
      socket.off('chat:new', onChatNew);
    };
  }, [socket, activeChat, refreshChats]);

  useEffect(() => {
    if (!activeChat || !token) { setMessages([]); setTypingUsers({}); return; }
    axios.get(`${API}/chats/${activeChat.id}/messages`, { headers: { Authorization: `Bearer ${token}` } })
      .then(r => setMessages(r.data)).catch(err => { console.error(err); setMessages([]); });
    if (socket) socket.emit('chat:join', { chatId: activeChat.id });
  }, [activeChat, token, API, socket]);

  const selectChat = (chat) => { setActiveChat(chat); setMobileChatOpen(true); };

  const startPrivateChat = async (userId) => {
    const res = await axios.post(`${API}/chats/private`, { userId }, { headers: { Authorization: `Bearer ${token}` } });
    const chat = res.data;
    setChats(prev => [chat, ...prev.filter(c => c.id !== chat.id)]);
    setActiveChat(chat);
    setMobileChatOpen(true);
    if (socket) socket.emit('chat:join', { chatId: chat.id });
    return chat;
  };

  const createGroup = async (name, memberIds) => {
    const res = await axios.post(`${API}/chats/group`, { name, memberIds }, { headers: { Authorization: `Bearer ${token}` } });
    const chat = res.data;
    setChats(prev => [chat, ...prev.filter(c => c.id !== chat.id)]);
    setActiveChat(chat);
    setMobileChatOpen(true);
    if (socket) {
      socket.emit('chat:join', { chatId: chat.id });
      socket.emit('group:created', { chatId: chat.id, members: chat.members });
    }
    return chat;
  };

  const removeChat = async (chat) => {
    await axios.delete(`${API}/chats/${chat.id}`, { headers: { Authorization: `Bearer ${token}` } });
    setChats(prev => prev.filter(c => c.id !== chat.id));
    if (activeChat?.id === chat.id) { setActiveChat(null); setMessages([]); setMobileChatOpen(false); }
  };

  const sendMessage = (text, mediaUrl = null, mediaType = null) => {
    if (!activeChat || !socket) return;
    socket.emit('message:send', { chatId: activeChat.id, text, mediaUrl, mediaType });
  };

  return (
    <main className={`chat-shell ${mobileChatOpen ? 'mobile-chat-open' : ''}`}>
      <Sidebar user={user} chats={chats} users={users} onlineMap={onlineMap} activeChat={activeChat}
        onSelectChat={selectChat} onStartPrivate={startPrivateChat} onCreateGroup={createGroup}
        onRemoveChat={removeChat} onLogout={logout} />
      <ChatWindow chat={activeChat} messages={messages} currentUser={user} typingUsers={typingUsers}
        onSend={sendMessage} socket={socket} token={token} API={API}
        onBack={() => setMobileChatOpen(false)} onlineMap={onlineMap} />
    </main>
  );
}
